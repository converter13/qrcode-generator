import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { useRef, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { generateQrCode } from "@/lib/qr";
import type { QrCode } from "@shared/schema";

export default function QrPreview() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const { data: latestQr } = useQuery<QrCode>({
    queryKey: ['/api/qr/latest'],
    enabled: false,
  });

  useEffect(() => {
    if (!latestQr || !canvasRef.current) return;

    generateQrCode(
      latestQr.data,
      latestQr.type,
      latestQr.customization || { color: "#000000", size: 300 }
    ).then(dataUrl => {
      const img = new Image();
      img.onload = () => {
        if (!canvasRef.current) return;
        const ctx = canvasRef.current.getContext('2d');
        if (!ctx) return;

        ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height);
        ctx.drawImage(img, 0, 0);
      };
      img.src = dataUrl;
    });
  }, [latestQr]);

  const handleDownload = (format: "png" | "svg") => {
    if (!canvasRef.current || !latestQr) return;

    const link = document.createElement("a");
    link.download = `qr-code-${latestQr.type}.${format}`;
    link.href = canvasRef.current.toDataURL();
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <Card>
      <CardContent className="p-6 flex flex-col items-center">
        <canvas 
          ref={canvasRef} 
          width={300}
          height={300}
          className="mb-4 border rounded-lg p-2" 
        />

        <div className="flex gap-2">
          <Button onClick={() => handleDownload("png")}>
            <Download className="h-4 w-4 mr-2" />
            PNG
          </Button>
          <Button onClick={() => handleDownload("svg")}>
            <Download className="h-4 w-4 mr-2" />
            SVG
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}