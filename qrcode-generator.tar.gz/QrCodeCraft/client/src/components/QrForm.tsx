import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { qrInsertSchema, qrTypeFields } from "@shared/schema";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface QrFormProps {
  type: string;
}

export default function QrForm({ type }: QrFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const fields = qrTypeFields[type];

  const form = useForm({
    resolver: zodResolver(qrInsertSchema),
    defaultValues: {
      type,
      data: Object.fromEntries(fields.map(f => [f, ""])),
      customization: {
        color: "#000000",
        size: 300,
      },
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/qr", data);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.setQueryData(['/api/qr/latest'], data);
      toast({
        title: "Success",
        description: "QR code generated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to generate QR code",
        variant: "destructive",
      });
    },
  });

  const onSubmit = form.handleSubmit((data) => mutation.mutate(data));

  return (
    <Form {...form}>
      <form onSubmit={onSubmit} className="space-y-4">
        {fields.map((field) => (
          <FormField
            key={field}
            control={form.control}
            name={`data.${field}`}
            render={({ field: formField }) => (
              <FormItem>
                <FormLabel>{field.charAt(0).toUpperCase() + field.slice(1)}</FormLabel>
                <FormControl>
                  <Input {...formField} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        ))}

        <FormField
          control={form.control}
          name="customization.color"
          render={({ field: formField }) => (
            <FormItem>
              <FormLabel>Color</FormLabel>
              <FormControl>
                <Input type="color" {...formField} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="customization.size"
          render={({ field: formField }) => (
            <FormItem>
              <FormLabel>Size</FormLabel>
              <FormControl>
                <Input 
                  type="range" 
                  min="100" 
                  max="1000" 
                  step="50"
                  {...formField}
                  onChange={(e) => formField.onChange(parseInt(e.target.value))}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <Button 
          type="submit" 
          className="w-full"
          disabled={mutation.isPending}
        >
          Generate QR Code
        </Button>
      </form>
    </Form>
  );
}