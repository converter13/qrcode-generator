import QRCode from "qrcode";

export function generateQrString(data: Record<string, string>, type: string): string {
  switch (type) {
    case "url":
      return data.url;
    case "text":
      return data.message;
    case "wifi":
      return `WIFI:T:${data.encryption};S:${data.ssid};P:${data.password};;`;
    case "contact":
      return `BEGIN:VCARD\nVERSION:3.0\nFN:${data.name}\nTEL:${data.phone}\nEMAIL:${data.email}\nORG:${data.organization}\nEND:VCARD`;
    case "social":
      return `https://${data.platform}.com/${data.username}`;
    case "email":
      return `mailto:${data.address}?subject=${encodeURIComponent(data.subject)}&body=${encodeURIComponent(data.body)}`;
    case "payment":
      return `${data.provider}:${data.identifier}?amount=${data.amount}`;
    default:
      throw new Error("Unsupported QR code type");
  }
}

export async function generateQrCode(
  data: Record<string, string>,
  type: string,
  options: { color: string; size: number },
): Promise<string> {
  const qrString = generateQrString(data, type);
  return QRCode.toDataURL(qrString, {
    width: options.size,
    margin: 2,
    color: {
      dark: options.color,
      light: "#ffffff",
    },
  });
}
