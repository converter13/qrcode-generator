import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import QrForm from "@/components/QrForm";
import QrPreview from "@/components/QrPreview";
import { qrTypeTitles } from "@shared/schema";
import { Wand2 } from "lucide-react";

export default function Home() {
  const [activeTab, setActiveTab] = useState("url");
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted p-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-primary to-primary-foreground bg-clip-text text-transparent">
            QR Code Generator
          </h1>
          <p className="text-muted-foreground mt-2">
            Create custom QR codes for anything with our easy-to-use generator
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardContent className="p-6">
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid grid-cols-2 sm:grid-cols-4 gap-1">
                  {Object.entries(qrTypeTitles).map(([type, title]) => (
                    <TabsTrigger key={type} value={type} className="flex items-center gap-2">
                      <Wand2 className="h-4 w-4" />
                      <span className="hidden sm:inline">{title}</span>
                    </TabsTrigger>
                  ))}
                </TabsList>
                {Object.keys(qrTypeTitles).map((type) => (
                  <TabsContent key={type} value={type}>
                    <QrForm type={type} />
                  </TabsContent>
                ))}
              </Tabs>
            </CardContent>
          </Card>

          <QrPreview />
        </div>
      </div>
    </div>
  );
}
