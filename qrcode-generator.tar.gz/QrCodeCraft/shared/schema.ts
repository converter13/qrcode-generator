import { pgTable, text, serial, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const qrCodes = pgTable("qr_codes", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(),
  data: jsonb("data").notNull(),
  customization: jsonb("customization").$type<{
    color: string;
    size: number;
    logo?: string;
  }>(),
});

export const qrInsertSchema = createInsertSchema(qrCodes).pick({
  type: true,
  data: true,
  customization: true,
}).extend({
  type: z.enum(["url", "text", "wifi", "contact", "social", "email", "payment"]),
  data: z.record(z.string(), z.string()),
  customization: z.object({
    color: z.string(),
    size: z.number().min(100).max(1000),
    logo: z.string().optional(),
  }),
});

export type QrCode = typeof qrCodes.$inferSelect;
export type InsertQrCode = z.infer<typeof qrInsertSchema>;

export const qrTypeTitles: Record<string, string> = {
  url: "Website URL",
  text: "Text Message",
  wifi: "WiFi Credentials",
  contact: "Contact Information",
  social: "Social Media",
  email: "Email",
  payment: "Payment Link"
};

export const qrTypeFields: Record<string, string[]> = {
  url: ["url"],
  text: ["message"],
  wifi: ["ssid", "password", "encryption"],
  contact: ["name", "phone", "email", "organization"],
  social: ["platform", "username"],
  email: ["address", "subject", "body"],
  payment: ["provider", "identifier", "amount"]
};
