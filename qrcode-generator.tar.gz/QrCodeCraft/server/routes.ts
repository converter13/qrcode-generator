import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { qrInsertSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/qr", async (req, res) => {
    try {
      const data = qrInsertSchema.parse(req.body);
      const qr = await storage.createQrCode(data);
      res.json(qr);
    } catch (error) {
      res.status(400).json({ error: "Invalid QR code data" });
    }
  });

  app.get("/api/qr/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ error: "Invalid QR code ID" });
    }

    const qr = await storage.getQrCode(id);
    if (!qr) {
      return res.status(404).json({ error: "QR code not found" });
    }

    res.json(qr);
  });

  const httpServer = createServer(app);
  return httpServer;
}
