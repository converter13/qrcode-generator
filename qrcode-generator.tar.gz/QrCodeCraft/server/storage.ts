import { qrCodes, type QrCode, type InsertQrCode } from "@shared/schema";

export interface IStorage {
  createQrCode(qr: InsertQrCode): Promise<QrCode>;
  getQrCode(id: number): Promise<QrCode | undefined>;
}

export class MemStorage implements IStorage {
  private qrCodes: Map<number, QrCode>;
  private currentId: number;

  constructor() {
    this.qrCodes = new Map();
    this.currentId = 1;
  }

  async createQrCode(qr: InsertQrCode): Promise<QrCode> {
    const id = this.currentId++;
    const newQr: QrCode = { ...qr, id };
    this.qrCodes.set(id, newQr);
    return newQr;
  }

  async getQrCode(id: number): Promise<QrCode | undefined> {
    return this.qrCodes.get(id);
  }
}

export const storage = new MemStorage();
